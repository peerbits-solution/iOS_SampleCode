//
//  SignUpViewController.swift
//  SampleCode
//
//  Created by Peerbits on 05/05/17.
//  Copyright © 2017 Peerbits. All rights reserved.
//

import UIKit

class SignUpViewController: UIViewController, UITextFieldDelegate
{
    
    
    //MARK: - OUTLETS -
    
    @IBOutlet weak var btnCreditCardCheckBox: UIButton!
    @IBOutlet weak var txtFirstName: JVFloatLabeledTextField!
    @IBOutlet var txtLastName: JVFloatLabeledTextField!
    @IBOutlet var txtEmail: JVFloatLabeledTextField!
    @IBOutlet var txtPassword: JVFloatLabeledTextField!
    @IBOutlet var btnTandC: UIButton!
    @IBOutlet var btnSubmit: UIButton!
    @IBOutlet var viewFirstName: UIView!
    @IBOutlet var viewLastname: UIView!
    @IBOutlet var viewPassword: UIView!
    @IBOutlet var viewEmail: UIView!
    
    //MARK: - Variables -
    
    var userDataDict : [String : String] = [String : String]()
    var userDataArr : NSMutableArray = NSMutableArray()
    var userId : Int = 0
    
    //MARK: - View LifeCycle -
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        btnCreditCardCheckBox.isSelected = false
        self.automaticallyAdjustsScrollViewInsets = false
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
    }
    
    //MARK: - Api Calling -
    
    func Login() // call loginApi
    {
        // if network connection then code will be execute
        
        if kNetworkController.checkNetworkStatus()
        {
            DELEGATE.showLoader()
            let parameters = ["":""]
            
            // Request Login Service
            AlamofireModel.alamofireMethod(.post, url: APIAction.LogIn.rawValue, parameters: parameters as [String : AnyObject], Header: ["":""], handler: { (response) in
                print(parameters)
                DELEGATE.hideLoader()
                
                // check for the reponse
                if (response.value(forKey: "code") as! Int == 200)
                {
                    
                }
                else
                {
                    let text = response.value(forKey: "message") as! String
                    JDStatusBarNotification.show(withStatus: text, dismissAfter: 3.0, styleName: JDStatusBarStyleError)
                }
                
            }) { (error) in
                print(error)
            }
        }
        else
        {
            InternetConnection()
        }
    }
    
    //MARK: - Textfeild Delegate -
    
    func textFieldDidEndEditing(_ textField: UITextField)
    {
        if txtFirstName.text != ""
        {
            viewFirstName.backgroundColor = textFieldSelelectedColor
        }
        else
        {
            viewFirstName.backgroundColor = textFieldEmptyColor
        }
        
        if txtLastName.text != ""
        {
            viewLastname.backgroundColor = textFieldSelelectedColor
        }
        else
        {
            viewLastname.backgroundColor = textFieldEmptyColor
        }
        
        if txtEmail.text != ""
        {
            viewEmail.backgroundColor = textFieldSelelectedColor
        }
        else
        {
            viewEmail.backgroundColor = textFieldEmptyColor
        }
        
        if txtPassword.text != ""
        {
            viewPassword.backgroundColor = textFieldSelelectedColor
        }
        else
        {
            viewPassword.backgroundColor = textFieldEmptyColor
        }
    }
    
    //MARK: - ACTIONS -
    @IBAction func backBtnAction(_ sender: UIButton)
    {
        // back to previous screen
        _ = self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btncrediCardCheckBoxAction(_ sender: UIButton)
    {
        // selec unselect credit card button
        if btnCreditCardCheckBox.isSelected == false {
            
            btnCreditCardCheckBox.isSelected = true
        }
        else {
            
            btnCreditCardCheckBox.isSelected = false
        }
    }
    
    
    @IBAction func btnContinueAction(_ sender: UIButton) {
        
        // Validations
        
        btnSubmit.validateScreen { (result, message) in
            if !result
            {
                // if not validate then return message
                JDStatusBarNotification.show(withStatus: message, dismissAfter: 3.0, styleName: JDStatusBarStyleError);
            }
            else
            {
                // check email is registered or not if registered then show message
                if defaults.value(forKey: txtEmail.text!) != nil
                {
                    let text = "Email already registered"
                    JDStatusBarNotification.show(withStatus: text, dismissAfter: 3.0, styleName: JDStatusBarStyleError)
                    return
                }
                
                //if not registered then new will be register
                DELEGATE.showLoader()
                userDataDict = ["firstname" : txtFirstName.text!,"lastname" : txtLastName.text!,"email" : txtEmail.text!,"password" : txtPassword.text!]
                defaults.setValue(userDataDict, forKey: txtEmail.text!)
                defaults.synchronize()
                self.perform(#selector(SignUpViewController.loader), with: self, afterDelay: 2.0)
                
            }
        }
    }
    
    func loader()
    {
        // after data storing process move to next screen
        DELEGATE.hideLoader()
        let resultVC = Utilities.viewController("LoginViewController", onStoryboard: "Authentication") as! LoginViewController
        self.navigationController!.pushViewController(resultVC, animated: true)
        
    }
    
    @IBAction func btnLoginAction(_ sender: UIButton)
    {
        // move to login screen
        
        if let navi = DELEGATE.window?.rootViewController?.childViewControllers {
            
            for viewController in navi {
               
                // check viewcontroller to pop it
                if viewController.isKind(of: LoginViewController.self) {
                   
                    let _ = self.navigationController?.popToViewController(viewController , animated: true)
                    return
                }
            }
            
            self.loader()
            
        }
        else{
            
            self.loader()
        }
    }
}
