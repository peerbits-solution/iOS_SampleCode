//
//  LogOutViewController.swift
//  SampleCode
//
//  Created by Peerbits on 05/05/17.
//  Copyright © 2017 Peerbits. All rights reserved.
//
import UIKit

class LogOutViewController: UIViewController
{

    //MARK: - View LifeCycle -
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
    }
    
    //MARK: - ACTION -
    
    @IBAction func btnOkAction(_ sender: Any)
    {
        dismiss(animated: true, completion: nil)
        
        // call method to set root view controller as login screen
        DELEGATE.goToLoginScreenPage(transition: true)
    }
    @IBAction func btnCancelAction(_ sender: Any)
    {
        dismiss(animated: true, completion: nil)
    }
}
