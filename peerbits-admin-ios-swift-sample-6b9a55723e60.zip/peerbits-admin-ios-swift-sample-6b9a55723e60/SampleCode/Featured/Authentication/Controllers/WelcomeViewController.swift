//
//  WelcomeViewController.swift
//  SampleCode
//
//  Created by Peerbits on 05/05/17.
//  Copyright © 2017 Peerbits. All rights reserved.
//

import UIKit

class WelcomeViewController: UIViewController {
    
    
    //MARK: - OUTLETS -
    
    @IBOutlet weak var btnLogin: UIButton!
    @IBOutlet weak var btnSignUp: UIButton!
    
    
    //MARK: - View LifeCycle -
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.loadViewIfNeeded()
        
        // give radius to buttons
        
        self.btnLogin.layer.cornerRadius = self.btnLogin.frame.size.height / 2
        self.btnSignUp.layer.cornerRadius = self.btnSignUp.frame.size.height / 2

    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
    }
    
    //MARK: - ACTION -
    
    @IBAction func btnLoginAction(_ sender: UIButton)
    {
        // Move to login screen
        let resultVC = Utilities.viewController("LoginViewController", onStoryboard: "Authentication") as! LoginViewController
        self.navigationController!.pushViewController(resultVC, animated: true)
    }
    
    
    @IBAction func btnSignUpAction(_ sender: UIButton)
    {
        // Move to sign in screen
        let resultVC = Utilities.viewController("SignUpViewController", onStoryboard: "Authentication") as! SignUpViewController
        self.navigationController!.pushViewController(resultVC, animated: true)
    }

}
