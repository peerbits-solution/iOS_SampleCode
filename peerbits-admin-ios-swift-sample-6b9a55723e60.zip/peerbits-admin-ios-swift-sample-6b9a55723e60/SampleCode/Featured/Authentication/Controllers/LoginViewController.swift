//
//  LoginViewController.swift
//  SampleCode
//
//  Created by Peerbits on 05/05/17.
//  Copyright © 2017 Peerbits. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController
{
    
    //MARK: - OUTLETS -
    
    @IBOutlet weak var btnLogin: UIButton!
    @IBOutlet weak var loginView: UIView!
    @IBOutlet weak var btnForgotPassword: UIButton!
    @IBOutlet weak var txtEmail: JVFloatLabeledTextField!
    @IBOutlet weak var txtPassword: JVFloatLabeledTextField!
    @IBOutlet var viewPassword: UIView!
    @IBOutlet var viewEmail: UIView!
    
    //MARK: - VARIABLS -
    
    var dictUserData : NSMutableDictionary = NSMutableDictionary()
    
    //MARK: - View LifeCycle -
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.automaticallyAdjustsScrollViewInsets = false
        
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
    }
    
    //MARK: - Api Calling -
    
    func Login() // LogiN api called
    {
        // if device is connected to network api will called

        if kNetworkController.checkNetworkStatus()
        {
            DELEGATE.showLoader()
            let parameters = ["":""]
            
            //Almofire Services
            
            AlamofireModel.alamofireMethod(.post, url: APIAction.LogIn.rawValue, parameters: parameters as [String : AnyObject], Header: ["":""], handler: { (response) in
                print(parameters)
                DELEGATE.hideLoader()
                
                // check for the reponse
                if (response.value(forKey: "code") as! Int == 200)
                {
                    
                }
                else
                {
                    let text = response.value(forKey: "message") as! String
                    JDStatusBarNotification.show(withStatus: text, dismissAfter: 3.0, styleName: JDStatusBarStyleError)
                }
                
            }) { (error) in
                print(error)
            }
        }
        else
        {
            InternetConnection()
        }
    }
    
    //MARK: - Textfeild Delegate -
    
    func textFieldDidEndEditing(_ textField: UITextField)
    {
        if txtEmail.text != "" {
            
            viewEmail.backgroundColor = textFieldSelelectedColor
        }
        else{
            
            viewEmail.backgroundColor = textFieldEmptyColor
        }
        
        if txtPassword.text != ""{
            
            viewPassword.backgroundColor = textFieldSelelectedColor
        }
        else{
            
            viewPassword.backgroundColor = textFieldEmptyColor
        }
    }

    //MARK: - ACTIONS -
    
    @IBAction func btnBackAction(_ sender: UIButton)
    {
        //Back to previous screen
        _ = self.navigationController?.popViewController(animated: true)
    }
    
    
    @IBAction func btnLoginAction(_ sender: UIButton)
    {
        btnLogin.validateScreen { (result, message) in
            if !result
            {
                JDStatusBarNotification.show(withStatus: message, dismissAfter: 3.0, styleName: JDStatusBarStyleError);
            }
            else
            {
                // if email is registed then goes for other execution
                if defaults.value(forKey: txtEmail.text!) != nil
                {
                    dictUserData = NSMutableDictionary(dictionary: defaults.value(forKey: txtEmail.text!)! as! NSDictionary)
                    
                    // if email and password validate then move to home screen
                    if  dictUserData.value(forKey: "email") as! String == txtEmail.text!
                    {
                        let password  =  dictUserData.value(forKey: "password") as! String
                        if password == txtPassword.text!
                        {
                            DELEGATE.showLoader()
                            self.perform(#selector(self.loader), with: self, afterDelay: 2.0)
                        }
                        else
                        {
                            // else error messge will show
                            let text = "Invalid email id or password"
                            JDStatusBarNotification.show(withStatus: text, dismissAfter: 3.0, styleName: JDStatusBarStyleError)
                        }
                    }
                }
                else
                {
                    // if email is not registed then show message
                    let text = "Email not registered"
                    JDStatusBarNotification.show(withStatus: text, dismissAfter: 3.0, styleName: JDStatusBarStyleError)
                }

            }
        }
    }
    
    // Hide loader and navigate to Home Screen
    func loader()
    {
        // after data checking process move to next screen
        DELEGATE.hideLoader()
        let HomeVC : HomeViewController = Utilities.viewController("HomeViewController", onStoryboard: StoryBoardName.Authentication.rawValue) as! HomeViewController
        self.navigationController?.pushViewController(HomeVC, animated: true)
        
    }
    
    // Action for navigate to Sign Up
    @IBAction func btnSignUpAction(_ sender: UIButton)
    {
        //Move to Sign up screen
       
        if let navi = DELEGATE.window?.rootViewController?.childViewControllers {
            
            for viewController in navi {
                
                // some process
                if viewController.isKind(of: SignUpViewController.self) {
                    
                    let _ = self.navigationController?.popToViewController(viewController , animated: true)
                    return
                }
            }
            self.moveToSignupScreen()
        }
        else{
            
            self.moveToSignupScreen()
        }
    }
    
    func moveToSignupScreen(){
    
        let resultVC = Utilities.viewController("SignUpViewController", onStoryboard: "Authentication") as! SignUpViewController
        self.navigationController!.pushViewController(resultVC, animated: true)
    }
    
    
    @IBAction func btnForgotPassword(_ sender: UIButton)
    {
        //Move to forget password  screen
        let resultVC = Utilities.viewController("ForgotPasswordViewController", onStoryboard: "Authentication") as! ForgotPasswordViewController
        self.navigationController!.pushViewController(resultVC, animated: true)
    }
    
}
