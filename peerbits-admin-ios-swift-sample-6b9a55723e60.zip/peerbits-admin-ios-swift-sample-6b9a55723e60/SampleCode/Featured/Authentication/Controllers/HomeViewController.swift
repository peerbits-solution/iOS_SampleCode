//
//  HomeViewController.swift
//  SampleCode
//
//  Created by Peerbits on 05/05/17.
//  Copyright © 2017 Peerbits. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController,UIWebViewDelegate
{
    
    //MARK: - Outlets -
    
    @IBOutlet var peerWebView: UIWebView!
   
    //MARK: - Variables -
    
    var myActivityIndicator : UIActivityIndicatorView = UIActivityIndicatorView()
    
    //MARK: - Life Cycle -
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        peerWebView.delegate = self
        myActivityIndicator = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.gray)
        myActivityIndicator.center = view.center
        myActivityIndicator.transform =  CGAffineTransform(scaleX: 1.5, y: 1.5)
        myActivityIndicator.hidesWhenStopped = false
        myActivityIndicator.color = textFieldSelelectedColor
        peerWebView.addSubview(myActivityIndicator)
        myActivityIndicator.startAnimating()
        self.peerWebView.loadRequest(URLRequest(url: URL(string: "https://www.peerbits.com/")!))

    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        
    }

    //MARK: - Web view delegate -
    
    func webView(_ webView: UIWebView, shouldStartLoadWith request: URLRequest, navigationType: UIWebViewNavigationType) -> Bool
    {
        myActivityIndicator.startAnimating()
        if navigationType == UIWebViewNavigationType.backForward {
            if (request.url?.host == "https://www.peerbits.com/"){
                return true
            } else {
                return false
            }
        }
        return true
    }
    
    func webViewDidFinishLoad(_ webView: UIWebView)
    {
        myActivityIndicator.stopAnimating()
        myActivityIndicator.hidesWhenStopped = true
    }
    

    //MARK: - Action -
    
    @IBAction func btnLogOutAction(_ sender: Any)
    {
        // Move to logout screen
        let logOutVc = Utilities.viewController("LogOutViewController", onStoryboard: StoryBoardName.Authentication.rawValue) as! LogOutViewController
        self.navigationController?.present(logOutVc, animated: true, completion: nil)
    }
}
