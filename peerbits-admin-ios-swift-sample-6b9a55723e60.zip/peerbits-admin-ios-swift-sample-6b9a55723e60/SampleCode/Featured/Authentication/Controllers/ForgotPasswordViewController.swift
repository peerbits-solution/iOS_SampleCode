//
//  ForgotPasswordViewController.swift
//  SampleCode
//
//  Created by Peerbits on 05/05/17.
//  Copyright © 2017 Peerbits. All rights reserved.
//

import UIKit

class ForgotPasswordViewController: UIViewController
{
    
    //MARK: - Outlets -
    @IBOutlet var viewEmail: UIView!
    @IBOutlet var btnSubmit: UIButton!
    @IBOutlet weak var txtEmail: JVFloatLabeledTextField!
    
    //MARK: - View LifeCycle -
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
    }
    
    //MARK: - Api Calling -
    
    func ForgetPassword()
    {
        // if device is connected with internet then api will called
        if kNetworkController.checkNetworkStatus()
        {
            DELEGATE.showLoader()
            let parameters = ["":""]
            
            AlamofireModel.alamofireMethod(.post, url: APIAction.LogIn.rawValue, parameters: parameters as [String : AnyObject], Header: ["":""], handler: { (response) in
                print(parameters)
                DELEGATE.hideLoader()
                
                if (response.value(forKey: "code") as! Int == 200)
                {
                    
                    
                }
                else
                {
                    let text = response.value(forKey: "message") as! String
                    JDStatusBarNotification.show(withStatus: text, dismissAfter: 3.0, styleName: JDStatusBarStyleError)
                }
                
            }) { (error) in
                print(error)
            }
        }
        else
        {
            InternetConnection()
        }
    }
    
    //MARK: - TextFeild Delegate -
  
    func textFieldDidEndEditing(_ textField: UITextField)
    {
        if txtEmail.text != ""
        {
            viewEmail.backgroundColor = textFieldSelelectedColor
        }
        else
        {
            viewEmail.backgroundColor = textFieldEmptyColor
        }
    }
    
    //MARK: - ACTIONS -
    
    @IBAction func btnBackAction(_ sender: UIButton){
        
        // move to previous screen
        _ = self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnSubmitAction(_ sender: UIButton){
        
        // check validation if all done then call api
        btnSubmit.validateScreen { (result, message) in
            
            if !result{
                
                JDStatusBarNotification.show(withStatus: message, dismissAfter: 3.0, styleName: JDStatusBarStyleError);
            }
            else{
                
                DELEGATE.showLoader()
                perform(#selector(ForgotPasswordViewController.EmailSend), with: self, afterDelay: 5)

            }
        }
    }
    
    func EmailSend()
    {
        // email sent message text
        DELEGATE.hideLoader()
        JDStatusBarNotification.show(withStatus: "Reset password link sent succesfully to your email address", dismissAfter: 3.0, styleName: JDStatusBarStyleError);
        perform(#selector(ForgotPasswordViewController.MoveToBack), with: self, afterDelay: 3)
    }
    
    func MoveToBack()
    {
        // move to previous screen
        _ = self.navigationController?.popViewController(animated: true)
    }
}
