//
//  User.swift
//  SampleCode
//
//  Created by Peerbits on 05/05/17.
//  Copyright © 2017 Peerbits. All rights reserved.
//

import Foundation
import SwiftyJSON

private var _sharedUser = User()
var kCurrentUser = User.sharedInstance

enum LoginType: String {
    case None = "none"
    case Google = "G"
    case Email = "email"
    case Twitter = "T"
}

class User: UserModel {
    
    var userDefaultKey = "user_information"
    var emailId : String?
    var contactNumber : String?
    var userId : Int!
    var ProfileImage : String?
    var countryCode : Int?
    var countryName : String?
    var username : String?
    var Is_Completed_Profile : String?
    
    
    override init()
    {
        super.init()
    }
    
    
    override init(info: JSON)
    {
        super.init(info: info)
    }
    
    
    class var sharedInstance: User
    {
        if _sharedUser.identifier == nil
        {
            _sharedUser.loadFromDefault()
        }
        return _sharedUser
    }
    
     func update1(_ info: JSON)
    {
        print(info)

        ProfileImage = info["user_image"].string
        userId = info["user_id"].intValue
        contactNumber = info["phone_number"].string
        emailId = info["email"].string
        countryCode = info["country_code"].intValue
        countryName = info["country_name"].string
        username = info["user_name"].string
        Is_Completed_Profile = info["is_profile_completed"].string
        saveToDefault()
    }
    
    
    
    func loadFromDefault()
    {
        let userDefault = UserDefaults.standard
        if let dicInfo = userDefault.object(forKey: userDefaultKey) as? [String: AnyObject] {
            update(dicInfo)
        }
    }
    
    // MARK - Loading from user default
    func update(_ dictionaryInfo: [String: AnyObject])
    {
        
        func boolFromDictionary(_ dicInfo: [String: AnyObject], key: String) -> Bool
        {
            if let optionalValue = dicInfo[key] as? Bool
            {
                return optionalValue
            }
            else
            {
                return false
            }
        }
        
        ProfileImage = dictionaryInfo["user_image"] as? String
        userId = dictionaryInfo["user_id"] as? Int
        emailId = dictionaryInfo["email"] as? String
        contactNumber = dictionaryInfo["phone_number"] as? String
        countryCode = dictionaryInfo["country_code"] as? Int
        countryName = dictionaryInfo["country_name"] as? String
        username = dictionaryInfo["user_name"] as? String
        Is_Completed_Profile = dictionaryInfo["is_profile_completed"]?.string
        
    }
    
    
    // MARK - Making dictionary to save to user default
    func dictionaryFromInfos() -> [String: AnyObject]
    {
        var dicInfo = [String: AnyObject]()
        
        dicInfo["email"] = emailId as AnyObject?
        dicInfo["user_image"] = ProfileImage as AnyObject?
        dicInfo["user_id"] = userId as AnyObject?
        dicInfo["phone_number"] = contactNumber as AnyObject?
        dicInfo["country_code"] = countryCode as AnyObject?
        dicInfo["country_name"] = countryName as AnyObject?
        dicInfo["user_name"] = username as AnyObject?
        dicInfo["is_profile_completed"] = Is_Completed_Profile as AnyObject?
        return dicInfo
    }
    
    func logOut()
    {
        
        //loginType = LoginType.None
        clearInstance()
    }
    
    // MARK - Save to user default
    func saveToDefault()
    {
        let userDefault = UserDefaults.standard
        userDefault.set(dictionaryFromInfos(), forKey: userDefaultKey)
        userDefault.synchronize()
    }
    
    
    func updateOTPStatus(_ status : Bool)
    {
        saveToDefault()
    }
    
    
    func clearInstance()
    {
        userId = nil
        contactNumber = nil
        saveToDefault()
      //  kCurrentUser = User()
    }
}

