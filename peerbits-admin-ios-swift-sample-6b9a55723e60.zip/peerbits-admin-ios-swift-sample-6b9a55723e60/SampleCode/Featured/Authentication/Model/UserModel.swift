//
//  Created by Peerbits on 19/01/16.
//  Copyright © 2016 Manoj MacMini12. All rights reserved.
//

import Foundation
import SwiftyJSON

class UserModel: NSObject {
    
    var identifier: String?
    
    override init() {
        super.init()
    }
    
    init(info: JSON) {
        super.init()
        update(info)
    }
    
    
    func update(_ info: JSON) {
        
    }
    
    var pushsetting: NSMutableDictionary?
}
