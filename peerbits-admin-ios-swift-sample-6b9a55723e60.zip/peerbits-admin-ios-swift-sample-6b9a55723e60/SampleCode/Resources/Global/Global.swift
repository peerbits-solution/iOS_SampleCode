//
//  Global.swift
//  SampleCode
//
//  Created by Peerbits on 05/05/17.
//  Copyright © 2017 Peerbits. All rights reserved.
//
import Foundation
import UIKit
import CoreLocation

struct screen {
    
    var ScreenRect            = UIScreen.main.bounds
    var Width                 = UIScreen.main.bounds.width
    var Height                = UIScreen.main.bounds.height
}


var textFieldSelelectedColor    = UIColor(red: 35/255.0,green: 31/255.0,blue: 32/255.0,alpha: 1.0)
var textFieldEmptyColor         = UIColor(red: 229/255.0,green: 232/255.0,blue: 238/255.0,alpha: 1.0)

var Usertype                             = "U"
var DeviceType                           = "I"
var DeviceId                             = "123456"
var isRealStateAdEditMode:Bool           = false
var defaults                             = UserDefaults.standard

// MARK: - List of all Append string on base api url -

enum APIAction : String
{
    case LogIn           = "/api/user/login"
}



//MARK: - StoryboardName -

enum StoryBoardName : String
{
    case Authentication     = "Authentication"
}

//MARK: - Error messge -

func InternetConnection()
{
     JDStatusBarNotification.show(withStatus: "The internet connection was lost.Please check connection!", dismissAfter: 3.0, styleName: JDStatusBarStyleError)
}


