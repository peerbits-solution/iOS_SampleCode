//
//  Utilities.swift
//  SampleCode
//
//  Created by Peerbits on 05/05/17.
//  Copyright © 2017 Peerbits. All rights reserved.
//

import Foundation
import UIKit

class Utilities
{
    // MARK: Load View Controller from Story Board
    class func viewController(_ name: String, onStoryboard storyboardName: String) -> UIViewController
    {
        let storyboard = UIStoryboard(name: storyboardName, bundle: nil)
        return storyboard.instantiateViewController(withIdentifier: name)
    }
    
    class func viewTableController(_ name: String, onStoryboard storyboardName: String) -> UITableViewController
    {
        let storyboard = UIStoryboard(name: storyboardName, bundle: nil)
        return storyboard.instantiateViewController(withIdentifier: name) as! UITableViewController
    }
    
    //MARK : Check DeviceType
    func isiPad() -> Bool
    {
        return UI_USER_INTERFACE_IDIOM() == .pad
    }
    
    // MARK : Validation
    class func isValidEmail(_ testStr:String) -> Bool
    {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        let result = emailTest.evaluate(with: testStr)
        return result
    }
    
    class func isValidPassword(_ testStr:String) -> Bool
    {
        return testStr.characters.count >= 6 ? true : false
    }
 
    class func isValidUsername(_ Input:String) -> Bool
    {
        let usernameRegEx = "\\A\\w{1,50}\\z"
        let Test = NSPredicate(format:"SELF MATCHES %@", usernameRegEx)
        return Test.evaluate(with: Input)
    }

    class func isValidName(_ name: String) -> Bool
    {
        let RegEx = "^\\w+( +\\w+)*$"
        let Test = NSPredicate(format:"SELF MATCHES %@", RegEx)
        return Test.evaluate(with: name)
    }
    
    class func isValidNumber (_ stringNumber: NSString) -> Bool {
        
        let numberRegex = "^\\s*([0-9]*)\\s*$"
        let predicate = NSPredicate(format:"SELF MATCHES %@", argumentArray:[numberRegex])
        
        return predicate.evaluate(with: stringNumber)
    }
    
        
    class func resizeImage(_ image: UIImage) -> UIImage
    {
        let size = image.size
        let targetSize : CGSize = CGSize(width: 400, height: 400)
        let widthRatio  = targetSize.width  / image.size.width
        let heightRatio = targetSize.height / image.size.height
        
        // Figure out what our orientation is, and use that to form the rectangle
        var newSize: CGSize
        if(widthRatio > heightRatio)
        {
            newSize = CGSize(width: size.width * heightRatio, height: size.height * heightRatio)
        }
        else
        {
            newSize = CGSize(width: size.width * widthRatio, height: size.height * widthRatio)
        }
        
        // This is the rect that we've calculated out and this is what is actually used below
        let rect = CGRect(x: 0, y: 0, width: newSize.width, height: newSize.height)
        
        // Actually do the resizing to the rect using the ImageContext stuff
        UIGraphicsBeginImageContextWithOptions(newSize, false, 1.0)
        image.draw(in: rect)
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return newImage!
        
    }
}

