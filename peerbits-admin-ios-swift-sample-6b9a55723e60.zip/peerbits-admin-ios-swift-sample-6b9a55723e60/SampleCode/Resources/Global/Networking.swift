//
//  AlamofireModel.swift
//  SampleCode
//
//  Created by Peerbits on 05/05/17.
//  Copyright © 2017 Peerbits. All rights reserved.
//

import UIKit
import Alamofire


var baseAPIURL : String = "" //API BASE URL

class AlamofireModel: NSObject
{
    typealias CompletionHandler = (_ response:AnyObject) -> Void
    typealias ErrorHandler = (_ error : NSError) -> Void
    
    
    class func alamofireMethod(_ methods: Alamofire.HTTPMethod , url : URLConvertible , parameters : [String : AnyObject],Header: [String: String], showActivityIndicator: Bool = true, handler:@escaping CompletionHandler,errorhandler : @escaping ErrorHandler)
    {
        var alamofireManager : Alamofire.SessionManager?
        
        var UrlFinal = ""
        do
        {
            try UrlFinal = baseAPIURL + url.asURL().absoluteString
        }catch{}
        
        
        if showActivityIndicator
        {
            //DELEGATE.showLoader()
        }
        
        
        let configuration = URLSessionConfiguration.default
        configuration.timeoutIntervalForResource = 25
        configuration.timeoutIntervalForRequest = 25
        
        alamofireManager = Alamofire.SessionManager(configuration: configuration)
        alamofireManager = Alamofire.SessionManager.default
        
        

        alamofireManager?.request(UrlFinal, method: methods, parameters: parameters, encoding: URLEncoding.default, headers: Header).responseJSON(queue: nil, options: JSONSerialization.ReadingOptions.mutableLeaves, completionHandler: { (response) in
            
            DELEGATE.hideLoader()
            //print(response.request)
            if response.result.isSuccess
            {
                if (response.result.value != nil)
                {
                    handler(response.result.value! as AnyObject)
                }
            }
            else
            {
                errorhandler(response.result.error as! NSError)
            }
            
        })
    }
}
