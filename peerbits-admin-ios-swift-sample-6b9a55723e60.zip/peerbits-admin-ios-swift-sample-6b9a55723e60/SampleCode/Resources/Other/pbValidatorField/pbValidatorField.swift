//
//  pbValidatorField.swift
//  pbValidatorFieldDemo
//
//  Created by Peerbits on 03/09/16.
//  Copyright © 2016 peerbits. All rights reserved.
//

import UIKit
import ObjectiveC

// enum for validation type
enum validationType : String {
    case None               = ""
    case Email              = "email"
    case Password           = "password"
    case Compare            = "compare"
    case PhoneNumber        = "phone"
    case URL                = "url"
}


//Extention of text field to check validations
@IBDesignable extension UITextField {
  
    // Keys to set and get associated objects
    fileprivate struct AssociatedKeys {
        
        static var isRequred            = "isRequred"
        static var RequredFieldMessage  = "RequredFieldMessage"
        static var ValidationMessage    = "ValidationMessage"
        static var MinTextLength        = "MinTextLength"
        static var MaxTextLength        = "MaxTextLength"
        static var ValidationType       = "ValidationType"
        static var TagOfFieldToCompare  = "TagOfFieldToCompare"
        static var CustomValidation     = "CustomValidation"
    }
    
    //IB: Bool which define field requirenment
    @IBInspectable var isRequred: Bool {
        
        get {
            return objc_getAssociatedObject(self, &AssociatedKeys.isRequred) as? Bool ?? false
        }
        set {
            objc_setAssociatedObject(self, &AssociatedKeys.isRequred, newValue, objc_AssociationPolicy.OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        }
    
    }
    
    // IB: If field is requred user should set failure message
    @IBInspectable var RequredFieldMessage: String {
        get {
            return objc_getAssociatedObject(self, &AssociatedKeys.RequredFieldMessage) as? String ?? ""
        }
        set {
            objc_setAssociatedObject(self, &AssociatedKeys.RequredFieldMessage, newValue, objc_AssociationPolicy.OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        }
    }
    
    // IB: Validation message other then reqired field
    @IBInspectable var ValidationMessage: String  {
        get {
            return objc_getAssociatedObject(self, &AssociatedKeys.ValidationMessage) as? String ?? ""
        }
        set {
            objc_setAssociatedObject(self, &AssociatedKeys.ValidationMessage, newValue, objc_AssociationPolicy.OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        }
    }
    
    // IB: Property to set minimum required font
    @IBInspectable var MinTextLength: NSInteger {
        get {
            return objc_getAssociatedObject(self, &AssociatedKeys.MinTextLength) as? NSInteger ?? 0
        }
        set {
            objc_setAssociatedObject(self, &AssociatedKeys.MinTextLength, newValue, objc_AssociationPolicy.OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        }
    }
    
    // IB: Property to set maximum required font
    @IBInspectable var MaxTextLength: NSInteger {
        get {
            return objc_getAssociatedObject(self, &AssociatedKeys.MaxTextLength) as? NSInteger ?? NSIntegerMax
        }
        set {
            objc_setAssociatedObject(self, &AssociatedKeys.MaxTextLength, newValue, objc_AssociationPolicy.OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        }
    }
    
    // IB: If user wants to compare this field with other one he/she needs to set tag of other field here
    @IBInspectable var TagOfFieldToCompare:NSInteger {
        
        get {
            return objc_getAssociatedObject(self, &AssociatedKeys.TagOfFieldToCompare) as? NSInteger ?? 0
        }
        set {
            objc_setAssociatedObject(self, &AssociatedKeys.TagOfFieldToCompare, newValue, objc_AssociationPolicy.OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        }
        
    }
    
    // IB: Validation type of Field
    @IBInspectable var ValidationType:String {
        
        get {
            return objc_getAssociatedObject(self, &AssociatedKeys.ValidationType) as? String ?? validationType.None.rawValue
        }
        set {
            objc_setAssociatedObject(self, &AssociatedKeys.ValidationType, newValue, objc_AssociationPolicy.OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        }
        
    }
    
    // IB: This property will be useful if user wants validation other then provided
    @IBInspectable var CustomValidation: String  {
        get {
            return objc_getAssociatedObject(self, &AssociatedKeys.CustomValidation) as? String ?? ""
        }
        set {
            objc_setAssociatedObject(self, &AssociatedKeys.CustomValidation, newValue, objc_AssociationPolicy.OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        }
    }
    
    // Function to check validations
    func isValid() -> (status : Bool, message : String) {
        
        // check empty field if required
        if isRequred {
            if pbValidationRules.isFieldEmpty(self.text!) {
                return (false,RequredFieldMessage)
            }
            
        }
        else if pbValidationRules.isFieldEmpty(self.text!)// Ignore field if not required and blank
        {
            return (true,ValidationMessage)
        }
        
        // check custom validation if set by developer
        if CustomValidation.characters.count > 0 {
            return (pbValidationRules.isValidRegx(self.text!, regx: CustomValidation),ValidationMessage)
        }
        
        // check cases for validation types
        switch ValidationType {
            
        case validationType.Email.rawValue://Email validation
            return (pbValidationRules.isValidEmail(self.text!),ValidationMessage)
         
        case validationType.Password.rawValue://Password validation
            return (pbValidationRules.isFieldLengthValid(self.text!,minlength: MinTextLength,maxlength: MaxTextLength),ValidationMessage)
            
        case validationType.PhoneNumber.rawValue://PhoneNumber validation default is (123-456-7890)
            return (pbValidationRules.isValidPhone(self.text!),ValidationMessage)
            
        case validationType.Compare.rawValue://Compare fields validation
            
            let viewContainer   = getMainViewOfCurrentScreen(self)//method to get view of controller
            let textField       = getFieldToCompare(viewContainer)// get text field to compare
            
            if textField != nil {
                return (pbValidationRules.isFieldsSame(self.text!, textToCompare: textField!.text!), ValidationMessage)
            }
            print("\n\nPlease set value(tag of other field) in Tag To Compare Field property\n\n")
            return (false,"comparison failed")
            
            
        case validationType.URL.rawValue://URL validation
            return (pbValidationRules.isValidateURL(self.text! as NSString),ValidationMessage)
            
           
        default://Default no validation
            return (true,ValidationMessage)
        }
    }
    
    //Method to get text field to compare with
    func getFieldToCompare(_ container : UIView) -> UITextField? {
        
        for subView in container.subviews {
            if subView.isKind(of: UITextField.self) {
                let field = subView as! UITextField
                if field.tag == TagOfFieldToCompare {
                    return field
                }
            }
            else
            {
                if subView.subviews.count > 0 {
                   let field = getFieldToCompare(subView)
                    if field != nil {
                        return field
                    }
                }
            }
        }
        
        return nil
    }
    
}


