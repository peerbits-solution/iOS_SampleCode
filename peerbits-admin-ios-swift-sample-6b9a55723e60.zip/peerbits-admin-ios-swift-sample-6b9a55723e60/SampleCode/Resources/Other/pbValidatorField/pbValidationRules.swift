//
//  pbValidationRules.swift
//  pbValidatorFieldDemo
//
//  Created by Peerbits on 05/09/16.
//  Copyright © 2016 peerbits. All rights reserved.
//

import UIKit

//Class for set rules on fields
class pbValidationRules: NSObject {
    
    // Rule for Email
  class func isValidEmail(_ input:String) -> Bool {
        
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        let result = emailTest.evaluate(with: input)
        return result
    }
    
    // Rule for Custom Reguler Expression
    class func isValidRegx(_ input:String,regx:String) -> Bool {
       
        let phoneTest = NSPredicate(format: "SELF MATCHES %@", regx)
        let result =  phoneTest.evaluate(with: input)
        return result
    }
    
    // Rule for Phone (US)
   class func isValidPhone(_ value: String) -> Bool {
        let PHONE_REGEX = "^\\d{3}-\\d{3}-\\d{4}$"
        let phoneTest = NSPredicate(format: "SELF MATCHES %@", PHONE_REGEX)
        let result =  phoneTest.evaluate(with: value)
        return result
    }
    
    // Rule for Match Fields
    class func isFieldsSame(_ fieldText: String , textToCompare : String) -> Bool {
        if fieldText == textToCompare{
            return true
        }
        else{
            return false
        }
    }
    
    // Rule for Check field length
    class func isFieldLengthValid(_ content: String , minlength : NSInteger, maxlength : NSInteger) -> Bool {
        if content.characters.count >= minlength && content.characters.count <= maxlength {
            return true
        }
        else{
            return false
        }
    }
    
    // Rule for field content length
    class func isFieldEmpty(_ input:String) -> Bool {
        
        if input.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines).characters.count == 0
        {
            return true;
        }
        
        return false;
    }
    
    // Rule for URL
    class func isValidateURL (_ stringURL : NSString) -> Bool {
        
        let urlRegEx = "((https|http)://)((\\w|-)+)(([.]|[/])((\\w|-)+))+"
        let predicate = NSPredicate(format:"SELF MATCHES %@", argumentArray:[urlRegEx])
        
        return predicate.evaluate(with: stringURL)
    }
    
}
