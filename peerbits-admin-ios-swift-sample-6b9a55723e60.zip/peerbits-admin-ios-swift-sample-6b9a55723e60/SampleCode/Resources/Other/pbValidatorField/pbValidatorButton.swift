//
//  pbValidatorButton.swift
//  pbValidatorFieldDemo
//
//  Created by Peerbits on 03/09/16.
//  Copyright © 2016 peerbits. All rights reserved.
//

import UIKit

// Extention to add validation method
extension UIButton {

    //method will get all fields from view and cehck validation for all
    func validateScreen(_ completion: (_ result: Bool,_ message : String) -> Void) {
    
        // get current view controller
        let viewController = UIApplication.shared.keyWindow?.currentViewController()
        
        // view contains fields
        var container : UIView
        
        // set container view
        if viewController != nil {
            container = viewController!.view
        }else{
            container = getMainViewOfCurrentScreen(self)
        }
        
        //check validation for view
        let result = checkValidationForView(container)
        
        // Handler for result
        completion(result.status,result.message)
        
    }
    
    // Method to check validation in field container
    func checkValidationForView(_ container : UIView) -> (status : Bool, message : String) {
        
        var _result     = true
        var _message    = ""
        
        for subView in container.subviews {
            if subView.isKind(of: UITextField.self) {
                let field = subView as! UITextField
                if !field.isValid().status {
                    return (false,field.isValid().message)
                }
            }
            else
            {
                if subView.subviews.count > 0 {
                    let validation = checkValidationForView(subView)
                    _result     = validation.status
                    _message    = validation.message
                    if !_result {
                        return (_result,_message)
                    }
                }
            }
        }
        
        return (_result,_message)
    }
    
}



//UIWindow  extention
public extension UIWindow {
    
    // Returns the current Top Most ViewController in hierarchy.
    override public func topMostController()->UIViewController? {
        
        var topController = rootViewController
        
        while let presentedController = topController?.presentedViewController {
            topController = presentedController
        }
        
        return topController
    }
    
    // Returns the topViewController in stack of topMostController.
    public func currentViewController()->UIViewController? {
        
        var currentViewController = topMostController()
        
        while currentViewController != nil && currentViewController is UINavigationController && (currentViewController as! UINavigationController).topViewController != nil {
            currentViewController = (currentViewController as! UINavigationController).topViewController
        }
        
        return currentViewController
    }
}



//UIView hierarchy category.
public extension UIView {
    
   
    // Returns the UIViewController object that manages the receiver.
    public func viewController()->UIViewController? {
        
        var nextResponder: UIResponder? = self
        
        repeat {
            nextResponder = nextResponder?.next
            
            if let viewController = nextResponder as? UIViewController {
                return viewController
            }
            
        } while nextResponder != nil
        
        return nil
    }
    
   
    // Returns the topMost UIViewController object in hierarchy.
    public func topMostController()->UIViewController? {
        
        var controllersHierarchy = [UIViewController]()
        
        if var topController = window?.rootViewController {
            controllersHierarchy.append(topController)
            
            while topController.presentedViewController != nil {
                
                topController = topController.presentedViewController!
                
                controllersHierarchy.append(topController)
            }
            
            var matchController :UIResponder? = viewController()
            
            while matchController != nil && controllersHierarchy.contains(matchController as! UIViewController) == false {
                
                repeat {
                    matchController = matchController?.next
                    
                } while matchController != nil && matchController is UIViewController == false
            }
            
            return matchController as? UIViewController
            
        } else {
            return viewController()
        }
    }
    
    // get view of current visible view controller
    public func getMainViewOfCurrentScreen(_ subView : UIView) -> UIView {
        
        if subView.superview != nil {
            if subView.superview!.bounds == UIScreen.main.bounds {
                return subView.superview!
            }else{
                let view = getMainViewOfCurrentScreen(subView.superview!)
                if view.bounds == UIScreen.main.bounds {
                    return view;
                }
            }
        }
        
        return subView
    }
    
}
