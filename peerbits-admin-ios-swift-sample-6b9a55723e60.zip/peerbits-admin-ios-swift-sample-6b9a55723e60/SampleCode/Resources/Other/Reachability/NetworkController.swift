//
//  NetworkController.swift
//  SampleCode
//
//  Created by Peerbits on 05/05/17.
//  Copyright © 2017 Peerbits. All rights reserved.
//

import UIKit

private let _sharedNetworkController = NetworkController()
let kNetworkController = NetworkController.sharedInstance

class NetworkController: NSObject {
    
    let reachability: Reachability = Reachability.forInternetConnection()
    var hasInternetConnection: Bool = false
    
    // MARK: Singleton
    /* init */
    override init() {
        super.init()
        /* <#comment#> */
        startUp()
    }
    
    /* shared instance */
    class var sharedInstance: NetworkController {
        return _sharedNetworkController
    }
    
    func checkNetworkStatus() -> Bool
    {
        let networkStatus: NetworkStatus = reachability.currentReachabilityStatus()
        hasInternetConnection = (networkStatus != NetworkStatus.NotReachable)
        
        if !hasInternetConnection
        {
            UIApplication.shared.endIgnoringInteractionEvents()
            //print(CCFD.getLocaliseString("INTERNET_CONNECTION_OFF"))
            //  AppInstance.showLoader()
            JDStatusBarNotification.show(withStatus: "Internet Connection is Off", dismissAfter: 3.0, styleName: JDStatusBarStyleError)
            //   Utilities.showToastWithErrorMessage(CCFD.getLocaliseString("INTERNET_CONNECTION_OFF"))
            return false
        }
        
        return true
    }
    
    // MARK: Handle network status
    func networkStatusDidChange(notification: NSNotification?)
    {
        let networkStatus: NetworkStatus = reachability.currentReachabilityStatus()
        hasInternetConnection = (networkStatus != NetworkStatus.NotReachable)
        
        if !hasInternetConnection {
            
            //print(CCFD.getLocaliseString("INTERNET_CONNECTION_OFF"))
            JDStatusBarNotification.show(withStatus: "Internet connection is off", dismissAfter: 3.0, styleName: JDStatusBarStyleError)
            // Utilities.showToastWithErrorMessage(CCFD.getLocaliseString("INTERNET_CONNECTION_OFF"))
        }
        else{
            //print(CCFD.getLocaliseString("INTERNET_CONNECTION_ON"))
            JDStatusBarNotification.show(withStatus: "Internet connection is on", dismissAfter: 3.0, styleName: JDStatusBarStyleError)
            // Utilities.showToastWithSuccessMessage(CCFD.getLocaliseString("INTERNET_CONNECTION_ON"))
        }
    }
    
    // MARK: Functions
    
    /* call this once at init */
    func startUp() {
        
        NotificationCenter.default.addObserver(self, selector: #selector(NetworkController.networkStatusDidChange), name: NSNotification.Name.reachabilityChanged, object: nil)
        reachability.startNotifier()
    }
}
